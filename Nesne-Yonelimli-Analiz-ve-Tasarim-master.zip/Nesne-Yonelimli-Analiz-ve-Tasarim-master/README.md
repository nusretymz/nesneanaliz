# NesneYonelimliAnalizVeTasarim
## Uygulamanın veritabanına bağlanabilmesi ve düzgün bir şekilde çalışabilmesi için postgresql modülünün projeye dahil edilmesi gerekmektedir
 Nesne Yönelimli Analiz ve Tasarım dersinin proje ödevi kodlarını içeren repo
